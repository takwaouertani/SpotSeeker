import { USE_EMULATOR } from "@angular/fire/compat/auth";

export const environment = {
  UseEmulators:true,
production:false,
 firebase :{
  apiKey: "AIzaSyABBA_oFMrFI3j4E9gTTB_01gQg9DpPe-s",
  authDomain: "spotseeker-75fcd.firebaseapp.com",
  projectId: "spotseeker-75fcd",
  storageBucket: "spotseeker-75fcd.appspot.com",
  messagingSenderId: "705756794537",
  appId: "1:705756794537:web:c38ef8517a54233b4723b8",
  measurementId: "G-ZXJMGRLHFV",
  databaseURL: "http://localhost:8082"

}
};
