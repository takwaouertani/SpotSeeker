import { Component } from '@angular/core';

@Component({
  selector: 'app-formulaire-reviews',
  templateUrl: './formulaire-reviews.component.html',
  styleUrl: './formulaire-reviews.component.css'
})
export class FormulaireReviewsComponent {


  
}
