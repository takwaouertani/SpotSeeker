import { Component } from '@angular/core';

@Component({
  selector: 'app-login-adherant',
  templateUrl: './login-adherant.component.html',
  styleUrl: './login-adherant.component.css'
})
export class LoginAdherantComponent {

}
