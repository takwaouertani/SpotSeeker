import { Component } from '@angular/core';

@Component({
  selector: 'app-adherant-register',
  templateUrl: './adherant-register.component.html',
  styleUrl: './adherant-register.component.css'
})
export class AdherantRegisterComponent {

}
