import { Component } from '@angular/core';

@Component({
  selector: 'app-adherant-accounts',
  templateUrl: './adherant-accounts.component.html',
  styleUrl: './adherant-accounts.component.css'
})
export class AdherantAccountsComponent {

}
