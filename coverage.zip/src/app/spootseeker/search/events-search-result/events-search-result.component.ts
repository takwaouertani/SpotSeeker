import { Component } from '@angular/core';

@Component({
  selector: 'app-events-search-result',
  templateUrl: './events-search-result.component.html',
  styleUrl: './events-search-result.component.css'
})
export class EventsSearchResultComponent {

}
