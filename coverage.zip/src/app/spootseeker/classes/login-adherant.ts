export class LoginAdherant {
    constructor(
        public email: string,
        public password: string,
        
    ){}
}
