declare module 'first-input-delay' {
    export function init(options: { callback: (firstInputDelay: number) => void }): void;
  }
  