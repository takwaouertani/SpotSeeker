import { Time } from '@angular/common';
import { Component } from '@angular/core';
import { Destination } from '../classes/destination';
import { OwnersRequestsService } from '../services/owners-requests.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-formulaire-proprietaire',
  templateUrl: './formulaire-proprietaire.component.html',
  styleUrl: './formulaire-proprietaire.component.css'
})
export class FormulaireProprietaireComponent {
  currentStep: number = 1;
  steps: any[] = [
    { iconClass: 'fa-regular fa-user' },  
    { iconClass: 'fa-sharp fa-solid fa-check-circle' }, 
    { iconClass: 'fa-sharp fa-solid fa-check-circle' },  
    { iconClass: 'fa-sharp fa-solid fa-check-circle' } ,
    { iconClass: 'fa-sharp fa-solid fa-check-circle' } 
  ];
  selectedCategory: string = ''; // Variable to store the selected category

  // Method to select a category
  selectCategory(cat: string) {
    this.category = cat;
  }
  addOptionInput() {
    this.showOptionInput = !this.showOptionInput;
  }
  isCategorySelected(cat: string): boolean {
    return this.category === cat;
  }
  showOptionInput = false;
  newOption = '';
  options: string[] = [];
  selecttype(type: string) {
    this.type_destination = type;
  }

  toggleOptionInput() {
    this.showOptionInput = !this.showOptionInput;
  }
  addOption() {
    console.log('Adding option:', this.newOption);
    
    // Check if the new option is not empty and not already included
    if (this.newOption.trim() !== '' && !this.options.includes(this.newOption)) {
        console.log('Option not empty and not already included. Adding to options array.');
        this.options.push(this.newOption); // Add the new option to the options array
        console.log('Options array:', this.options);
        this.newOption = ''; // Clear the input field after adding the option
    } else {
        console.log('Option is empty or already included in options array.');
    }
}

  

  

  selectType(type: string) {
    this.type_destination = type;
  }
  istypeSelected(type: string): boolean {
    return this.type_destination === type;
  }

  nextStep() {
    if (this.currentStep < this.steps.length) {
      this.currentStep++;
    }
  }

  previousStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }
  updateValue(event: Event, span: HTMLSpanElement) {
    const target = event.target as HTMLInputElement;
    const value = parseInt(target.value);
    const adjustedValue = Math.round(value / 5) * 5;
    span.textContent = adjustedValue.toString();
  }


  constructor(private owner_destination:OwnersRequestsService,  
    private router: Router
  ){}
  destinationlist:Destination[]=[];


  destinationobj: Destination = {
    id_destination: '',
    name_destination: '',
    adresse: '',
    description: '',
    category: '',
    type_destination: '',
    menu: [],
    smoking_area: false,
    wifi_availibily: false,
    pet_friendly: false,
    kids_corner: false,
    parking: false,
    credit_card: false,
    reservation: false,
    opening_hour: { hours: 0, minutes: 0 },
    closing_hour: { hours: 0, minutes: 0 },
    price_range: 0,
    email_destination: '',
    destinaition_phone_number: 0,
    facebook: '',
    instagram: '',
    website: '',
    ownerdata: [],
    city: '',
    state: '',
    rate: '',
    images: []
  };
  step: number = 1;
  
   
  
  id_destination:string='';
     name_destination : string='';
     adresse:string='';
     description:string='';
     category:string='';
     type_destination:string='';
     menu:string='';
     smoking_area:boolean=false;
     wifi_availibily:boolean=false;
     pet_friendly:boolean=false;
     kids_corner:boolean=false;
     parking:boolean=false;
     credit_card:boolean=false;
     reservation:boolean=false;
     opening_hour:Time={
      hours: 0,
      minutes: 0
     };
     closing_hour:Time={
      hours: 0,
      minutes: 0
     };
  
     price_range:number=0;
     email_destination:string='';
     destinaition_phone_number:number=0;
     facebook:string="";
     instagram:string="";
     website:string='';
   
     eventImages: FileList | null = null; // Property to hold the selected event images
     onEventImagesSelected(event: any) {
      this.eventImages = event.target.files; // Set the selected event images
    }
// to add a destination
adddestination() {
  const dynamicRowsData = this.ownerdata.map(row => ({
    first_name: row.first_name,
    last_name: row.last_name,
    email: row.email,
    Phone_number: row.Phone_number,
    
  }));
  const eventImagesURLs: string[] = [];
    if (this.eventImages) {
      for (let i = 0; i < this.eventImages.length; i++) {
        const imageURL = URL.createObjectURL(this.eventImages[i]);
        eventImagesURLs.push(imageURL);
      }
    }
  const destinationobj: Destination = {
    id_destination: '',
    name_destination: this.name_destination,
    adresse: this.adresse,
    description: this.description,
    category: this.category,
    type_destination: this.type_destination,
    menu: eventImagesURLs,
    smoking_area: this.smoking_area,
    wifi_availibily: this.wifi_availibily,
    pet_friendly: this.pet_friendly,
    kids_corner: this.kids_corner,
    parking: this.parking,
    credit_card: this.credit_card,
    reservation: this.reservation,
    opening_hour: this.opening_hour,
    closing_hour: this.closing_hour,
    price_range: this.price_range,
    email_destination: this.email_destination,
    destinaition_phone_number: this.destinaition_phone_number,
    facebook: this.facebook,
    instagram: this.instagram,
    website: this.website,
    ownerdata: dynamicRowsData,
    city: '',
    state: '',
    rate: '',
    images: []
  };

  this.owner_destination.addowner_request(destinationobj).then(() => {
      alert('Destination added successfully!');
    this.router.navigate(['/home']);
}).catch(error => {
      // Check if the error is related to ownerdata
      if (error.message.includes('ownerdata')) {
          console.error('Error adding ownerdata:', error);
          alert('Failed to add ownerdata. Please check the provided data and try again.');
      } else {
          console.error('Error adding destination:', error);
          alert('Failed to add destination. Please try again.');
      }
  });
}

ownerdata: { first_name: string, last_name: string, email: string, Phone_number: number }[] = [{ first_name: '', last_name: '', email: '', Phone_number: 0 }];

uploadedImages: { file: File, url: string }[] = []; // Array to hold selected images and their URLs

onFileSelected(event: any) {
  const files: FileList = event.target.files; // Get selected files
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const url = URL.createObjectURL(file); // Create URL for the image
    this.uploadedImages.push({ file, url }); // Push file and its URL to uploadedImages array
  }
}

deleteImage(index: number) {
  URL.revokeObjectURL(this.uploadedImages[index].url); // Revoke the object URL to free memory
  this.uploadedImages.splice(index, 1); // Remove the image from the array
}





}





